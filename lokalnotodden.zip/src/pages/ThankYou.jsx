import React from "react";

const ThankYou = () => {
  return (
    <div style={{ padding: "4rem", textAlign: "center" }}>
      <h1>Takk for meldingen din! 🙌</h1>
      <p>Vi svarer deg så snart vi kan.</p>
    </div>
  );
};

export default ThankYou;
