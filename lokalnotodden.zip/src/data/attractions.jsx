export const attractions = [
  {
    id: 1,
    title: "Heddal Stavkirke",
    slug: "heddal-stavkirke",
    category: "Historisk",
    description:
      "Heddal Stavkirke er Norges største og best bevarte stavkirke, og et storslått eksempel på middelaldersk håndverk og arkitektur. Den ble bygget tidlig på 1200-tallet og er rikt dekorert med intrikate treskjæringer som kombinerer både kristne og førkristne symboler. Stavkirken er fortsatt i bruk som sognekirke og tiltrekker seg besøkende fra hele verden som ønsker å oppleve dens unike atmosfære og historie. Om sommeren tilbys det guidede turer som gir et dypere innblikk i kirkens opprinnelse, restaureringsarbeidet og dens rolle i norsk kulturarv. Kirken er omgitt av en vakker kirkegård og landskap, og det finnes en besøkssenter med utstilling, kafé og suvenirbutikk. Dette er et must for historieinteresserte og alle som ønsker å forstå den norske identiteten gjennom arkitektur og tro.",
    address: "Heddalsvegen 412, 3676 Notodden, Norge",
    hours: "Daglig 10:00 - 18:00",
    highlights: [
      "Norges største stavkirke",
      "Middelaldersk arkitektur",
      "Guidede turer tilgjengelig",
    ],
    imageUrl: "/images/stavkirke.jpg",
    mapUrl:
      "https://maps.google.com/maps?q=Heddalsvegen+412,+Notodden,+Norway&output=embed",
  },
  {
    id: 2,
    title: "Notodden Blues Festival",
    slug: "notodden-blues-festival",
    category: "Festival",
    description:
      "Notodden Blues Festival er en internasjonalt anerkjent musikkfestival som hvert år forvandler Notoddens gater og torg til et pulserende mekka for blueselskere. Siden starten i 1988 har festivalen vokst til å bli en av Europas viktigste arenaer for blues, og tiltrekker seg verdensstjerner innen sjangeren, så vel som norske talenter. Festivalen byr på konserter på små intime scener, i kirker, ute på gatene og i store telt – alt med en uformell og inkluderende stemning. I tillegg arrangeres det blues-workshops, utstillinger, barneprogram, og den populære matfestivalen som feirer både lokal og internasjonal matkultur. For bluesentusiaster er dette en fest for sansene, og for turister er det en unik måte å oppleve norsk musikkglede og gjestfrihet på.",
    address: "Torvet, 3674 Notodden",
    hours: "August (årlig event)",
    highlights: [
      "Internasjonale bluesartister",
      "Flere scener i sentrum",
      "Matfestival samtidig",
    ],
    imageUrl: "/images/bluesfestival.jpg",
    mapUrl: "https://maps.google.com/maps?q=Torvet,+3674+Notodden&output=embed",
  },
  {
    id: 3,
    title: "Telemarkskanalen",
    slug: "telemarkskanalen",
    category: "Natur",
    description:
      "Telemarkskanalen er et mesterverk av norsk ingeniørkunst fra 1800-tallet, ofte omtalt som 'de åtte underverker'. Kanalen strekker seg over 105 km mellom Skien og Dalen, og passerer gjennom åtte sluseanlegg med totalt 18 sluser. Denne historiske vannveien gjør det mulig å seile gjennom spektakulært landskap, små bygder og frodig natur. Du kan gå ombord på MS Victoria eller MS Henrik Ibsen for en elegant og avslappende reise i rolig tempo, hvor du får innsikt i både lokal historie og kanalens funksjon i det moderne Norge. For aktive reisende finnes det også sykkelruter og turstier langs kanalen. Det er en ideell destinasjon for barnefamilier, par og historieinteresserte som ønsker å kombinere kultur og natur i en uforglemmelig opplevelse.",
    address: "Kanalveien, 3674 Notodden",
    hours: "Mai–September: daglige avganger",
    highlights: [
      "Historiske sluser",
      "Båttur med MS Victoria/Henrik Ibsen",
      "Vakker natur langs kanalen",
    ],
    imageUrl: "/images/telemarkskanalen.jpg",
    mapUrl: "https://maps.google.com/maps?q=Kanalveien,+Notodden&output=embed",
  },
  {
    id: 4,
    title: "Norsk Industriarbeidermuseum",
    slug: "norsk-industriarbeidermuseum",
    category: "Museum",
    description:
      "Norsk Industriarbeidermuseum på Vemork er en av Norges mest betydningsfulle museer, og gir en dyp innsikt i industrialiseringens påvirkning på samfunnet. Museet ligger i det tidligere kraftverket Vemork, kjent fra tungtvannsaksjonen under andre verdenskrig. Her får du lære om både den teknologiske utviklingen, arbeiderklassens livsvilkår, og Norges rolle i kampen mot atomvåpenproduksjon. Utstillingene er moderne og interaktive, med lyd, film og autentiske gjenstander. Museet tilbyr også guidede turer, foredrag og en egen utstilling om aksjonen mot tungtvannsanlegget som ble verdenskjent gjennom film og litteratur. En tur hit er lærerik for både barn og voksne og setter ting i perspektiv både historisk og etisk.",
    address: "Tinfosveien 30, 3674 Notodden",
    hours: "Tirsdag–Søndag: 11:00–16:00",
    highlights: [
      "Industrihistorie",
      "Tungtvannsaksjonen",
      "Interaktive utstillinger",
    ],
    imageUrl: "/images/industrimuseum.jpg",
    mapUrl:
      "https://maps.google.com/maps?q=Tinfosveien+30,+Notodden&output=embed",
  },
  {
    id: 5,
    title: "Gaustatoppen",
    slug: "gaustatoppen",
    category: "Natur",
    description:
      "Gaustatoppen rager majestetisk 1883 meter over havet og tilbyr en av Norges mest spektakulære utsikter. På en klar dag kan du se omtrent en sjettedel av hele landet fra toppen. Fjellet er lett tilgjengelig for de fleste – du kan gå til fots via godt merkede stier, eller ta Gaustabanen, en spektakulær kabelbane som går inne i fjellet og bringer deg nesten helt opp til toppen. På toppen finner du en liten kafé, utsiktsplattformer og rikelig med fotomuligheter. Gaustatoppen er populær både sommer og vinter – som et turmål, for toppturer på ski, eller bare som en rolig flukt til fjells. Landskapet rundt er dramatisk og vakkert, og gir en uforglemmelig opplevelse for naturelskere og eventyrere.",
    address: "Gaustablikk, 3660 Rjukan",
    hours: "Sesongbasert – sjekk vær og åpningstider",
    highlights: [
      "1883 meter over havet",
      "Spektakulær utsikt",
      "T-bane til toppen (Gaustabanen)",
    ],
    imageUrl: "/images/gaustatoppen.jpg",
    mapUrl: "https://maps.google.com/maps?q=Gaustablikk,+Rjukan&output=embed",
  },
  {
    id: 6,
    title: "Rjukan og Vemork",
    slug: "rjukan-og-vemork",
    category: "Historisk",
    description:
      "Rjukan og Vemork er et historisk kjerneområde i Telemark som står på UNESCOs verdensarvliste, takket være sin industrielle og militærhistoriske betydning. Vemork var stedet for den berømte tungtvannsaksjonen under andre verdenskrig, der norske sabotører stoppet Nazi-Tysklands planer om å utvikle atomvåpen. I dag huser anlegget Norsk Industriarbeidermuseum, som formidler denne dramatiske historien gjennom engasjerende utstillinger og dokumentarfilm. I selve Rjukan finner du Krossobanen – Europas første kabelbane – og Solspeilet som bringer sollys til dalbunnen i vintermånedene. Byen er omkranset av majestetiske fjell og er et godt utgangspunkt for friluftsaktiviteter som fotturer og klatring. En tur hit er både lærerik og inspirerende, med dype røtter i både norsk industri og motstandskamp.",
    address: "Vemork, 3660 Rjukan",
    hours: "Daglig 10:00–16:00",
    highlights: [
      "UNESCO Verdensarv",
      "Andre verdenskrigs historie",
      "Industrimuseum og Krossobanen",
    ],
    imageUrl: "/images/rjukan.jpg",
    mapUrl: "https://maps.google.com/maps?q=Vemork,+Rjukan&output=embed",
  },
];
